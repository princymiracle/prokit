import 'package:flutter/material.dart';

class AnimatedDefaultTextPage extends StatefulWidget {
  const AnimatedDefaultTextPage({super.key});

  @override
  State<AnimatedDefaultTextPage> createState() => _AnimatedDefaultTextPageState();
}

class _AnimatedDefaultTextPageState extends State<AnimatedDefaultTextPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
