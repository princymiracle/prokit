class IconPath{
  static const onboarding = "assets/icons/icon_onboarding.png";
  static const login = "assets/icons/icon_login.png";
  static const signup = "assets/icons/icon_signup.png";
  static const verification = "assets/icons/icon_verification.png";
  static const forgortpass = "assets/icons/icon_forgortpass.png";
  static const home = "assets/icons/icon_home.png";
  static const user = "assets/icons/icon_user.png";
  static const userpro = "assets/icons/icon_userpro.png";
  static const contanct = "assets/icons/icon_contanct.png";
  static const productlist = "assets/icons/icon_productlist.png";
  static const timeline = "assets/icons/icon_timeline.png";
  static const notification = "assets/icons/icon_notification.png";
  static const leaf = "assets/icons/icon_leaf.png";
  static const leaf1 = "assets/icons/icon_leaf1.png";
  static const  curlybracket = "assets/icons/icon_curlybracket.png";

}